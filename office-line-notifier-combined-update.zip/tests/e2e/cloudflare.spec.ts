import {openSettingsTab} from './settings-tools';
import {expectConversationStatus,chooseConversationStatus} from './chat-tools';
import {migrationStatements} from '../migrations';
import{productionCryptoLimit}from'../production-crypto';
import{test,expect}from'@playwright/test';
import{Miniflare}from'miniflare';
import{build}from'esbuild';
import{readFileSync}from'node:fs';
import{spawn,type ChildProcess}from'node:child_process';
import{randomBytes,randomUUID,createHmac}from'node:crypto';
import{passwordHash}from'../../worker/security';
import {unzipSync,strFromU8} from 'fflate';
const origin='http://localhost:5174';
let mf:Miniflare,vite:ChildProcess;
const username='browser-'+randomUUID(),password=randomBytes(24).toString('hex'),authPepper=randomBytes(32).toString('hex'),bindingPepper=randomBytes(32).toString('hex'),lineSecret=randomBytes(32).toString('hex');
let lineCalls:any[]=[],lineStatus=200;
test.beforeAll(async()=>{
 const built=await build({entryPoints:['worker/index.ts'],bundle:true,format:'esm',platform:'browser',write:false});
  mf=new Miniflare({modules:true,script:productionCryptoLimit+built.outputFiles[0].text,compatibilityDate:'2026-07-01',d1Databases:['DB'],bindings:{ALLOWED_ORIGIN:origin,COOKIE_SECURE:'false',AUTH_PEPPER:authPepper,BINDING_PEPPER:bindingPepper,LINE_CHANNEL_SECRET:lineSecret,LINE_CHANNEL_ACCESS_TOKEN:randomBytes(32).toString('hex'),LINE_SEND_ENABLED:'true'},outboundService:async(req:any)=>{if(req.url.endsWith('/v2/bot/info'))return new Response(JSON.stringify({basicId:'@office-e2e-test'}));lineCalls.push(await req.json());return new Response('{}',{status:lineStatus});}});
 const db=await mf.getD1Database('DB');await db.batch(migrationStatements().map(sql=>db.prepare(sql)));
 const now=new Date().toISOString();await db.prepare('INSERT INTO admins VALUES(?,?,?,?,?,?,?,?)').bind('browser-admin',username,'瀏覽器測試管理員',await passwordHash(password,authPepper),'admin',1,now,now).run();
 vite=spawn(process.execPath,['node_modules/vite/bin/vite.js','--host','localhost','--port','5174','--strictPort'],{env:{...process.env,VITE_APP_MODE:'cloudflare',VITE_API_BASE:'/api',VITE_BASE_PATH:'/'},stdio:'ignore'});
 let ready=false;for(let i=0;i<100;i++){if(vite.exitCode!==null)throw Error('正式模式 Vite 提前停止；請確認 5174 埠沒有被其他程序占用');try{if((await fetch(origin)).ok){ready=true;break;}}catch{}await new Promise(r=>setTimeout(r,100));}if(!ready)throw Error('正式模式測試前端未啟動');
});
test.afterAll(async()=>{vite?.kill();await mf?.dispose();});
// 各情境使用獨立瀏覽器但共用測試 D1；只隔離測試登入計數，不更動正式限流規則。
test.beforeEach(async()=>{const db=await mf.getD1Database('DB');await db.prepare("DELETE FROM rate_limits WHERE key GLOB 'login-*'").run();});
test('Cloudflare 模式：實際 Cookie 登入、綁定、推播 Mock、簽章 Webhook、輪詢顯示與登出',async({page})=>{
 test.setTimeout(90000);
 const errors:string[]=[];page.on('pageerror',error=>errors.push(error.message));
 // 將瀏覽器 API 導向真實本機 workerd＋D1；對外 LINE HTTP 為 Mock，沒有真實個資或憑證。
 await page.route(origin+'/api/**',async route=>{const req=route.request();const response=await mf.dispatchFetch('http://localhost'+(new URL(req.url()).pathname+new URL(req.url()).search),{method:req.method(),headers:await req.allHeaders(),...(req.method()==='POST'?{body:req.postData()!}:{})});await route.fulfill({status:response.status,headers:Object.fromEntries(response.headers),body:await response.text()});});
 await page.goto(origin);await page.getByLabel('登入帳號',{exact:true}).fill(username);await page.getByLabel('密碼',{exact:true}).fill(password);await page.getByRole('button',{name:'登入辦公室'}).click();await expect(page.getByRole('heading',{name:'值班工作台'})).toBeVisible();await expect(page.locator('.demo-banner')).toHaveCount(0);
 await page.getByRole('button',{name:'教師名單',exact:true}).click();await page.getByRole('button',{name:'新增教師'}).click();await page.getByLabel('教師姓名',{exact:true}).fill('虛構整合測試教師');await page.getByLabel('所屬單位',{exact:true}).fill('測試單位');await page.getByRole('button',{name:'儲存教師',exact:true}).click();
 const row=page.getByRole('row').filter({hasText:'虛構整合測試教師'});await row.getByRole('button',{name:'產生綁定碼'}).click();const code=await page.locator('.code').textContent();await expect(page.getByAltText('虛構整合測試教師的個人綁定 QR Code')).toBeVisible();await expect(page.getByRole('button',{name:'複製綁定連結'})).toBeVisible();await page.getByRole('button',{name:'關閉',exact:true}).click();
 const uid='U'+randomUUID();const hook=async(text:string)=>{const raw=JSON.stringify({events:[{webhookEventId:randomUUID(),timestamp:Date.now(),type:'message',source:{type:'user',userId:uid},message:{type:'text',id:randomUUID(),text},replyToken:randomBytes(16).toString('hex')}]});const response=await mf.dispatchFetch('http://localhost/api/line/webhook',{method:'POST',headers:{'x-line-signature':createHmac('sha256',lineSecret).update(raw).digest('base64')},body:raw});expect(response.status).toBe(200);};
 await hook(code!);await expect(row.getByText('已綁定',{exact:true})).toBeVisible({timeout:20000});
 await page.getByRole('button',{name:'發送通知',exact:true}).click();await page.locator('.teacher-option').getByRole('checkbox').check();await page.getByRole('button',{name:'預覽通知'}).click();await page.getByRole('button',{name:'確認發送給 1 位教師'}).click();await expect(page.getByRole('dialog')).toHaveCount(0);expect(lineCalls.some(c=>c.to===uid&&c.messages[0].text.includes('信件'))).toBe(true);
 await page.getByRole('button',{name:/^訊息中心/}).click();await page.locator('.chat-teacher').click();await expect(page.locator('.attachment-hint')).toHaveText('文件及附件請使用辦公室 Email 傳送');await hook('測試教師回覆已收到');await expect(page.locator('.messages')).toContainText('測試教師回覆已收到',{timeout:10000});
  await expect(page.getByLabel('回覆後完成對話')).toHaveCount(0);
  lineStatus=401;await page.getByLabel('回覆老師',{exact:true}).fill('辦公室網頁回覆測試');await page.getByRole('button',{name:'送出',exact:true}).click();
  await expect(page.getByRole('dialog')).toHaveCount(0);await expect(page.getByRole('alert')).toContainText('LINE 連線設定需要更新');await expect(page.getByLabel('回覆老師',{exact:true})).toHaveValue('辦公室網頁回覆測試');await expectConversationStatus(page,'待回覆');await expect(page.locator('.messages')).not.toContainText('辦公室網頁回覆測試');
  lineStatus=200;await page.getByRole('button',{name:'送出',exact:true}).click();await expect(page.getByRole('dialog')).toHaveCount(0);await expectConversationStatus(page,'已完成');await expect(page.getByLabel('回覆老師',{exact:true})).toHaveValue('');await expect(page.locator('.messages')).toContainText('辦公室網頁回覆測試');await expect(page.locator('body')).not.toContainText('API 已接受');
  await chooseConversationStatus(page,'待回覆');lineStatus=503;await page.getByLabel('回覆老師',{exact:true}).fill('結果未明保留草稿測試');await page.getByRole('button',{name:'送出',exact:true}).click();await expect(page.getByRole('alert')).toContainText('發送結果尚未確認');const callsBefore=lineCalls.length;
  await page.getByRole('button',{name:'通知紀錄',exact:true}).click();await page.getByRole('button',{name:/^訊息中心/}).click();await page.locator('.chat-teacher').click();await expect(page.getByLabel('回覆老師',{exact:true})).toHaveValue('結果未明保留草稿測試');await page.getByRole('button',{name:'送出',exact:true}).click();await expect(page.getByRole('alert')).toContainText('發送結果尚未確認');expect(lineCalls.length).toBe(callsBefore);await expectConversationStatus(page,'待回覆');lineStatus=200;
 await page.reload();await expect(page.getByRole('heading',{name:'值班工作台'})).toBeVisible();await page.getByRole('button',{name:'系統管理',exact:true}).click();await page.getByRole('button',{name:'新增行政帳號'}).click();await page.getByLabel('登入帳號',{exact:true}).fill('staff-'+randomUUID());await page.getByLabel('初始密碼',{exact:true}).fill(randomBytes(20).toString('hex'));await page.getByLabel('顯示名稱',{exact:true}).fill('虛構新行政人員');await page.getByRole('button',{name:'儲存權限'}).click();await expect(page.getByRole('dialog')).toHaveCount(0);await expect(page.locator('.settings-grid')).toContainText('虛構新行政人員');
 await page.getByRole('button',{name:'登出',exact:true}).click();await expect(page.getByRole('button',{name:'登入辦公室'})).toBeVisible();expect(errors).toEqual([]);
});

test('預覽網址提供正式入口並停用登入，不送出帳密',async({page},info)=>{
 let attempts=0;
 await page.route(origin+'/api/**',async route=>{const req=route.request();if(new URL(req.url()).pathname==='/api/login')attempts++;const response=await mf.dispatchFetch('http://localhost'+new URL(req.url()).pathname,{method:req.method(),headers:await req.allHeaders(),...(req.method()==='POST'?{body:req.postData()!}:{})});await route.fulfill({status:response.status,headers:Object.fromEntries(response.headers),body:await response.text()});});
 await page.route(origin+'/api/public-info',route=>route.fulfill({json:{name:'辦公室小幫手',origin:'https://office-line-notifier.pages.dev',version:'2026.11.17.2'}}));
 await page.goto(origin);await expect(page.getByRole('alert')).toContainText('請從正式網站登入');await expect(page.getByRole('link',{name:'前往正式網站'})).toHaveAttribute('href','https://office-line-notifier.pages.dev/');await expect(page.getByRole('button',{name:'登入辦公室'})).toBeDisabled();await expect(page.getByLabel('登入帳號',{exact:true})).toBeDisabled();expect(attempts).toBe(0);await page.screenshot({path:info.outputPath('preview-login.png'),fullPage:true,animations:'disabled'});
});

test('正式模式查詢超過 500 筆的舊通知，更新與復原後畫面同步',async({page})=>{
 const db=await mf.getD1Database('DB'),tid=randomUUID(),prefix=randomUUID(),now=new Date().toISOString(),callsBefore=lineCalls.length;
 await db.prepare("INSERT INTO teachers(id,name,line_user_id,bound_at,binding_version,created_at,updated_at) VALUES(?,?,?, ?,1,?,?)").bind(tid,'虛構歷史查詢教師','U'+randomUUID(),now,now,now).run();
 await db.prepare(`WITH RECURSIVE seq(n) AS(SELECT 1 UNION ALL SELECT n+1 FROM seq WHERE n<520)
 INSERT INTO notifications(id,request_id,teacher_id,kind,content,sender_id,binding_version,retry_key,send_status,status,created_at,sent_at)
 SELECT ?||n,?||n,?,'mail',CASE WHEN n=1 THEN '資料庫舊紀錄100%完整文字' ELSE '其他歷史通知'||n END,'browser-admin',1,?||n,'accepted','待領取',
 CASE WHEN n=1 THEN '2025-01-01T00:00:00.000Z' ELSE ? END,CASE WHEN n=1 THEN '2025-01-01T00:00:00.000Z' ELSE ? END FROM seq`).bind('n-'+prefix,'r-'+prefix,tid,'retry-'+prefix,now,now).run();
 await page.route(origin+'/api/**',async route=>{const req=route.request();const response=await mf.dispatchFetch('http://localhost'+new URL(req.url()).pathname+new URL(req.url()).search,{method:req.method(),headers:await req.allHeaders(),...(req.method()==='POST'?{body:req.postData()!}:{})});await route.fulfill({status:response.status,headers:Object.fromEntries(response.headers),body:await response.text()});});
 await page.goto(origin);await page.getByLabel('登入帳號',{exact:true}).fill(username);await page.getByLabel('密碼',{exact:true}).fill(password);await page.getByRole('button',{name:'登入辦公室'}).click();await expect(page.getByRole('heading',{name:'值班工作台'})).toBeVisible();
 await page.getByRole('button',{name:'通知紀錄',exact:true}).click();await page.getByLabel('搜尋通知').fill('資料庫舊紀錄100%');await expect(page.locator('tbody tr')).toHaveCount(1);await expect(page.locator('tbody')).toContainText('資料庫舊紀錄100%完整文字');
 const status=page.getByLabel('更新虛構歷史查詢教師處理狀態');await status.selectOption('已完成');await expect(status).toHaveValue('已完成');await page.locator('.toast').getByRole('button',{name:'復原',exact:true}).click();await expect(status).toHaveValue('待領取');expect(lineCalls.length).toBe(callsBefore);
 await page.getByRole('button',{name:'查看虛構歷史查詢教師的通知內容'}).click();await page.getByRole('button',{name:'前往對話'}).click();await page.getByRole('button',{name:'返回通知紀錄',exact:true}).click();await expect(page.getByLabel('搜尋通知')).toHaveValue('資料庫舊紀錄100%');await expect(page.locator('tbody tr')).toHaveCount(1);
});

test('正式模式完整交接搜尋、完成內容更正後查詢即更新，登出清除通知搜尋',async({page})=>{
 const db=await mf.getD1Database('DB'),now=new Date().toISOString();
 await db.prepare(`WITH RECURSIVE seq(n) AS(SELECT 1 UNION ALL SELECT n+1 FROM seq WHERE n<1010) INSERT INTO handovers(id,content,created_by,creator_name,handover_name,created_at,completed_at,completed_by,finisher_name) SELECT 'browser-handover-'||n,CASE WHEN n=1 THEN '資料庫舊交接100%' ELSE '其他交接'||n END,'browser-admin','測試管理員','測試交接人',?,CASE WHEN n=1 THEN '2025-11-16T16:01:00.000Z' ELSE ? END,'browser-admin','測試完成人' FROM seq`).bind(now,now).run();
 await page.route(origin+'/api/**',async route=>{const req=route.request();const response=await mf.dispatchFetch('http://localhost'+new URL(req.url()).pathname+new URL(req.url()).search,{method:req.method(),headers:await req.allHeaders(),...(req.method()==='POST'?{body:req.postData()!}:{})});await route.fulfill({status:response.status,headers:Object.fromEntries(response.headers),body:await response.text()});});
 const login=async()=>{await page.getByLabel('登入帳號',{exact:true}).fill(username);await page.getByLabel('密碼',{exact:true}).fill(password);await page.getByRole('button',{name:'登入辦公室'}).click();await expect(page.getByRole('heading',{name:'值班工作台'})).toBeVisible();};
 await page.goto(origin);await login();await page.getByRole('button',{name:'系統管理',exact:true}).click();const history=page.locator('.handover-history');await openSettingsTab(page,'records');await history.getByRole('button',{name:'特定日期',exact:true}).click();await page.getByLabel('交接紀錄日期',{exact:true}).fill('2025-11-17');await page.getByLabel('搜尋交接紀錄').fill('資料庫舊交接');await expect(history.locator('.handover-row')).toHaveCount(1);await expect(history).toContainText('資料庫舊交接100%');
 await history.getByRole('button',{name:'更正',exact:true}).click();await page.getByLabel('交接內容').fill('資料庫舊交接100% 更正完成');await page.getByRole('button',{name:'儲存更正',exact:true}).click();await expect(history.locator('.handover-row')).toContainText('更正完成');
 await page.getByRole('button',{name:'通知紀錄',exact:true}).click();await page.getByLabel('搜尋通知').fill('登出前的搜尋條件');await page.getByRole('button',{name:'登出',exact:true}).click();await expect(page.getByRole('button',{name:'登入辦公室'})).toBeVisible();await login();await page.getByRole('button',{name:'通知紀錄',exact:true}).click();await expect(page.getByLabel('搜尋通知')).toHaveValue('');
});

test('正式模式三秒輕量檢查、不重讀未變更對話，背景暫停且可接收自填物品',async({page})=>{
 test.setTimeout(45000);const db=await mf.getD1Database('DB'),now=new Date().toISOString(),tid=randomUUID(),uid='U'+randomUUID();
 await db.prepare('INSERT INTO teachers(id,name,line_user_id,bound_at,binding_version,created_at,updated_at) VALUES(?,?,?,?,1,?,?)').bind(tid,'虛構快速同步教師',uid,now,now,now).run();
 await db.prepare(`INSERT INTO notifications(id,request_id,teacher_id,kind,pickup_name,content,sender_id,binding_version,retry_key,send_status,status,created_at) VALUES(?,?,?,'custom','測試教材','請領取教材','browser-admin',1,?,'accepted','待領取',?)`).bind(randomUUID(),randomUUID(),tid,randomUUID(),now).run();
 const counts={data:0,conversation:0,changes:0};
 await page.route(origin+'/api/**',async route=>{const req=route.request(),url=new URL(req.url());if(url.pathname==='/api/data')counts.data++;if(url.pathname==='/api/conversation')counts.conversation++;if(url.pathname==='/api/changes')counts.changes++;const response=await mf.dispatchFetch('http://localhost'+url.pathname+url.search,{method:req.method(),headers:await req.allHeaders(),...(req.method()==='POST'?{body:req.postData()!}:{})});await route.fulfill({status:response.status,headers:Object.fromEntries(response.headers),body:await response.text()});});
 await page.goto(origin);await page.getByLabel('登入帳號',{exact:true}).fill(username);await page.getByLabel('密碼',{exact:true}).fill(password);await page.getByRole('button',{name:'登入辦公室'}).click();await page.getByRole('button',{name:/^訊息中心/}).click();await page.locator('.chat-teacher').filter({hasText:'虛構快速同步教師'}).click();
 await page.waitForResponse(r=>r.url().endsWith('/api/changes')&&r.status()===304,{timeout:10000});const previous={...counts};await page.waitForResponse(r=>r.url().endsWith('/api/changes')&&r.status()===304,{timeout:7000});expect(counts.data).toBe(previous.data);expect(counts.conversation).toBe(previous.conversation);
 const raw=JSON.stringify({events:[{webhookEventId:randomUUID(),timestamp:Date.now(),type:'message',source:{type:'user',userId:uid},message:{type:'text',id:randomUUID(),text:'三秒同步新訊息'}}]});expect((await mf.dispatchFetch('http://localhost/api/line/webhook',{method:'POST',headers:{'x-line-signature':createHmac('sha256',lineSecret).update(raw).digest('base64')},body:raw})).status).toBe(200);await expect(page.locator('.messages')).toContainText('三秒同步新訊息',{timeout:10000});
 await page.getByRole('button',{name:/^待領取物品/}).click();await expect(page.locator('.chat-pickups')).toContainText('測試教材');await page.getByRole('button',{name:'關閉輔助面板'}).click();
 await page.clock.install();await page.evaluate(()=>{Object.defineProperty(document,'hidden',{configurable:true,get:()=>true});document.dispatchEvent(new Event('visibilitychange'));});const hiddenChecks=counts.changes;await page.clock.runFor(30000);expect(counts.changes).toBe(hiddenChecks);
});

test('正式模式管理員預覽並清理 D1 舊操作紀錄，更新畫面且保留清理稽核',async({page},info)=>{
 const db=await mf.getD1Database('DB'),logId='cleanup-browser-'+randomUUID(),old='2024-01-01T00:00:00.000Z',callsBefore=lineCalls.length;
 await db.prepare("INSERT INTO audit_logs(id,actor_id,action,created_at) VALUES(?,'browser-admin','login',?)").bind(logId,old).run();
 await page.route(origin+'/api/**',async route=>{const req=route.request(),url=new URL(req.url());const response=await mf.dispatchFetch('http://localhost'+url.pathname+url.search,{method:req.method(),headers:await req.allHeaders(),...(req.method()==='POST'?{body:req.postData()!}:{})});await route.fulfill({status:response.status,headers:Object.fromEntries(response.headers),body:await response.text()});});
 await page.goto(origin);await page.getByLabel('登入帳號',{exact:true}).fill(username);await page.getByLabel('密碼',{exact:true}).fill(password);await page.getByRole('button',{name:'登入辦公室'}).click();await page.getByRole('button',{name:'系統管理',exact:true}).click();const panel=page.locator('.record-cleanup');await openSettingsTab(page,'maintenance');
 await panel.getByLabel('清理日期').fill('2024-01-02');await panel.getByLabel('已完成通知與聊天',{exact:true}).uncheck();await panel.getByLabel('已完成交接',{exact:true}).uncheck();await panel.getByLabel('舊操作紀錄',{exact:true}).check();await panel.getByRole('button',{name:'預覽可清理紀錄'}).click();await expect(panel.locator('.cleanup-preview .cleanup-counts b')).toHaveText(['0 筆','0 則','0 筆','1 筆']);await panel.screenshot({path:info.outputPath('cloudflare-cleanup.png'),animations:'disabled'});
 await panel.getByLabel('刪除確認文字').fill('刪除紀錄');await panel.getByRole('button',{name:'確認永久刪除'}).click();await expect(panel.getByRole('status')).toContainText('清理完成');expect(await db.prepare('SELECT id FROM audit_logs WHERE id=?').bind(logId).first()).toBeNull();
 const audit:any=await db.prepare("SELECT * FROM audit_logs WHERE action='records_cleanup' ORDER BY created_at DESC LIMIT 1").first();expect(audit.actor_id).toBe('browser-admin');expect(JSON.parse(audit.details).counts.audits).toBe(1);await expect(panel.locator('.cleanup-demo-tools')).toHaveCount(0);await openSettingsTab(page,'records');await expect(page.locator('.operation-history')).toContainText('清理舊紀錄');expect(lineCalls.length).toBe(callsBefore);
});

test('正式模式產生完整 ZIP 備份，不呼叫 LINE，且不匯出密碼或 LINE User ID',async({page})=>{
 const callsBefore=lineCalls.length;
 await page.route(origin+'/api/**',async route=>{const req=route.request(),url=new URL(req.url());const response=await mf.dispatchFetch('http://localhost'+url.pathname+url.search,{method:req.method(),headers:await req.allHeaders(),...(req.method()==='POST'?{body:req.postData()!}:{})});await route.fulfill({status:response.status,headers:Object.fromEntries(response.headers),body:await response.text()});});
 await page.goto(origin);await page.getByLabel('登入帳號',{exact:true}).fill(username);await page.getByLabel('密碼',{exact:true}).fill(password);await page.getByRole('button',{name:'登入辦公室'}).click();await page.getByRole('button',{name:'系統管理',exact:true}).click();await openSettingsTab(page,'maintenance');const event=page.waitForEvent('download');await page.getByRole('button',{name:'下載 ZIP 備份'}).click();const download=await event,files=unzipSync(new Uint8Array(readFileSync((await download.path())!))),json=JSON.parse(strFromU8(files['records.json']));expect(json.records.staff.length).toBeGreaterThan(0);expect(strFromU8(files['records.json'])).not.toContain('password_hash');expect(strFromU8(files['records.json'])).not.toContain('line_user_id');expect(strFromU8(files['records.json'])).not.toContain(authPepper);expect(lineCalls.length).toBe(callsBefore);
});
test('正式模式備份讀取期間登出，不會在登入畫面下載舊帳號資料',async({page})=>{
 let release:()=>void=()=>{},started:()=>void=()=>{};const wait=new Promise<void>(resolve=>{release=resolve;}),entered=new Promise<void>(resolve=>{started=resolve;});let held=false,downloads=0;page.on('download',()=>downloads++);
 await page.route(origin+'/api/**',async route=>{const req=route.request(),url=new URL(req.url()),body=req.postDataJSON();if(url.pathname==='/api/command'&&body?.action==='records_backup_page'&&!held){held=true;started();await wait;}const response=await mf.dispatchFetch('http://localhost'+url.pathname+url.search,{method:req.method(),headers:await req.allHeaders(),...(req.method()==='POST'?{body:req.postData()!}:{})});await route.fulfill({status:response.status,headers:Object.fromEntries(response.headers),body:await response.text()});});
 await page.goto(origin);await page.getByLabel('登入帳號',{exact:true}).fill(username);await page.getByLabel('密碼',{exact:true}).fill(password);await page.getByRole('button',{name:'登入辦公室'}).click();await page.getByRole('button',{name:'系統管理',exact:true}).click();await openSettingsTab(page,'maintenance');await page.getByRole('button',{name:'下載 ZIP 備份'}).click();await entered;await page.getByRole('button',{name:'登出',exact:true}).click();await expect(page.getByRole('button',{name:'登入辦公室'})).toBeVisible();const response=page.waitForResponse(r=>r.url().endsWith('/api/command')&&r.status()===401);release();await response;expect(downloads).toBe(0);
});
